<!DOCTYPE html> 
<html> 

<head> 
	<title> 
		JavaScript 
	| Detecting arrow key presses. 
	</title> 
</head> 

<body style="text-align:center;" id="body"> 
<div>gjhgsdfjg jshfj</div><?php include 'welcome.php';readfile("one.txt");?>

</body> 

</html> 
