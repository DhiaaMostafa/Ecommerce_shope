		<div class="footer"></div>
		<script src="js/jquery-1.12.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/selectBoxIt.min.js"></script>
		<script src="js/Test.js"></script>
		<script>
	 $('.live').keyup(function () {
	$($(this).data('class')).text($(this).val());
   });
		</script>
	</body>
</html>