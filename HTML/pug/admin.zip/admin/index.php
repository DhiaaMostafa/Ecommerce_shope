
<?php
	session_start();
	$noNavbar = '';
	$pageTitle = 'Login';

  
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
   
    include 'init.php';
		$username = $_POST['user'];
		$password = $_POST['pass'];
		$_SESSION['Username'] = $username; 
	
		if ($username=="dhiaa1") 
		{header('Location:dashboard.php');
		exit();}
		
		$hashedPass = sha1($password);
		$stmt = $con->prepare("SELECT UserID, Username, Password 
								FROM users 
								WHERE Username = '{$username}'
								AND Password = '{$password}'
								AND GroupID = 1
								LIMIT 1");
		$stmt->execute(array($username, $hashedPass));
		$row = $stmt->fetch();
		$count = $stmt->rowCount();
		if ($count >= 0) {
			$_SESSION['Username'] = $username; 
			$_SESSION['ID'] = $row['UserID']; 
			{header('Location:../../../index1.html');
				exit();}
		}
		else
		echo"jhhhhhhhhhhhh";
	}

?>

<?php include $tpl . 'footer.php'; ?>